let idEl = document.getElementById("ide");
let idErrMsgEl = document.getElementById("idErrMsg");
let firstNameEl = document.getElementById("firstname");
let firstNameErrMsgEl = document.getElementById("firstNameErrMsg");
let lastNameEl = document.getElementById("lastname");
let lastNameErrMsgEl = document.getElementById("lastNameErrMsg");

let emailEl = document.getElementById("email");
let emailErrMsgEl = document.getElementById("emailErrMsg");
let departmentEl = document.getElementById("department");
let departmentErrMsgEl = document.getElementById("departmentErrMsg");
let addBtnEl = document.getElementById("addBtn");
let editBtnEl = document.getElementById("editBtn");
let deleteBtnEl = document.getElementById("deleteBtn");



let myFormEl = document.getElementById("myForm");

let formData = {
    id: "",
    firstname: "",
    lastname: "",
    email: "",
    department: ""
};

idEl.addEventListener("change", function(event) {
    if (event.target.value === "") {
        idErrMsgEl.textContent = "Required*";
    } else {
        idErrMsgEl.textContent = "";
    }

    formData.id = event.target.value;
});
firstNameEl.addEventListener("change", function(event) {
    if (event.target.value === "") {
        firstNameErrMsgEl.textContent = "Required*";
    } else {
        firstNameErrMsgEl.textContent = "";
    }

    formData.firstname = event.target.value;
});
lastNameEl.addEventListener("change", function(event) {
    if (event.target.value === "") {
        lastNameErrMsgEl.textContent = "Required*";
    } else {
        lastNameErrMsgEl.textContent = "";
    }

    formData.lastname = event.target.value;
});

emailEl.addEventListener("change", function(event) {
    if (event.target.value === "") {
        emailErrMsgEl.textContent = "Required*";
    } else {
        emailErrMsgEl.textContent = "";
    }

    formData.email = event.target.value;
});
departmentEl.addEventListener("change", function(event) {
    if (event.target.value === "") {
        departmentErrMsgEl.textContent = "Required*";
    } else {
        departmentErrMsgEl.textContent = "";
    }

    formData.department = event.target.value;
});

function validateFormData(formData) {
    let {
        id,
        firstname,
        lastname,
        email,
        department
    } = formData;
    if (id === "") {
        idErrMsgEl.textContent = "Required*";
    }
    if (firstname === "") {
        firstNameErrMsgEl.textContent = "Required*";
    }
    if (lastname === "") {
        lastNameErrMsgEl.textContent = "Required*";
    }
    if (department === "") {
        departmentErrMsgEl.textContent = "Required*";
    }
    if (email === "") {
        emailErrMsgEl.textContent = "Required*";
    }
}




function submitPostFormData(formData) {

    let options = {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: "Bearer 4a448af27914a9724964899f5c43bcdad51d6f90be502754e7e88fede749a83c",
        },
        body: JSON.stringify(formData)
    };

    let url = "https://jsonplaceholder.typicode.com/users";

    fetch(url, options)
        .then(function(response) {
            return response.json();
        })
        .then(function(jsonData) {
            console.log(jsonData);


        });
}




function submitEditFormData(formData) {
    formData = {
        id: "",
        firstname: "",
        lastname: "",
        email: "",
        department: ""
    };


    let options = {
        method: "PUT",
        headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: "Bearer 4a448af27914a9724964899f5c43bcdad51d6f90be502754e7e88fede749a83c",
        },
        body: JSON.stringify(formData)
    };

    let url = "https://jsonplaceholder.typicode.com/users/11";

    fetch(url, options)
        .then(function(response) {
            return response.json();
        })
        .then(function(jsonData) {
            console.log(jsonData);


        });
}

function submitDeleteFormData(formData) {
    let options = {
        method: "DELETE",
        headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: "Bearer 4a448af27914a9724964899f5c43bcdad51d6f90be502754e7e88fede749a83c",
        },
        //body: JSON.stringify(formData)
    };

    let url = "https://jsonplaceholder.typicode.com/users/11";

    fetch(url, options)
        .then(function(response) {
            return response.json();
        })
        .then(function(jsonData) {
            console.log(jsonData);


        });
}






try {
    addBtnEl.addEventListener("click", function(event) {
        event.preventDefault();
        validateFormData(formData);
        submitPostFormData(formData);
    });
    editBtnEl.addEventListener("click", function(event) {
        event.preventDefault();

        submitEditFormData(formData);
    });
    deleteBtnEl.addEventListener("click", function(event) {
        event.preventDefault();
        //validateFormData(formData);
        submitDeleteFormData(formData);
    });
} catch (error) {
    console.log(error);
}